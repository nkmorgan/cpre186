import 'package:blackjack/card.dart';
import 'dart:collection';

class CardConstuctor {

   static List<card> cards() {
   var list = List<card>();
    for(int i = 1; i <= 9; ++i) {
      list.add(card(i, i, "Hearts", 'assets/images/' + i.toString() + 'H.png'));
      list.add(card(i, i, "Diamonds", 'assets/images/' + i.toString() + 'D.png'));
      list.add(card(i, i, "Spades", 'assets/images/' + i.toString() + 'S.png'));
      list.add(card(i, i, "Clubs", 'assets/images/' + i.toString() + 'C.png'));
    }
    for(int i = 10; i <= 13; ++i) {
      list.add(card(i, 10, "Hearts", 'assets/images/' + i.toString() + 'H.png'));
      list.add(card(i, 10, "Diamonds", 'assets/images/' + i.toString() + 'D.png'));
      list.add(card(i, 10, "Spades", 'assets/images/' + i.toString() + 'S.png'));
      list.add(card(i, 10, "Clubs", 'assets/images/' + i.toString() + 'C.png'));
    }
    list.shuffle();
    return list;
  }

 /* static void shuffle(List<card> deck) {
    deck.shuffle();
  } */


  static card hit(List<card> deck) {
   return deck.removeLast();
  }

}