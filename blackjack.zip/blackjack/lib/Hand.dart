import 'package:blackjack/card.dart';
import 'dart:collection';

class Hand{
   static List<card> Dealerhand() {
    var list = List<card>();
    return list;
  }

 static List<card> Playerhand() {
    var list = List<card>();
    return list;
  }


}