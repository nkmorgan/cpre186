import 'package:flutter/material.dart';


class card {
    var num = 0;
    var value = 0;
    String suit;
    var assets = 'assets/images/card.png';
    card(this.num, this.value, this.suit, this.assets);
}