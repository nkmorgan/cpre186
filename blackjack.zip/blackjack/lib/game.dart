import 'package:blackjack/card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'Hand.dart';
import 'card.dart';
import 'CardConstuctor.dart';
import 'dart:ui';

void main() => runApp(Game());

class Game extends StatefulWidget {
  @override
  _Game createState() => _Game();
}

class _Game extends State<Game> {
  int money = 5000;
  int bett = 0;
  bool initScreen = false;
  card pcard;
 static bool makeDeck = true;
  List<card> playerHand = Hand.Playerhand();
  List<card> dealerHand = Hand.Dealerhand();
 static List<card> c;
 CardConstuctor a = new CardConstuctor();
  List<card> deck = CardConstuctor.cards();
  card facedown = new card(0, 0, "face down", "assets/images/blue_back.png");
  int playhand = 0;
  int dealhand = 0;
  bool lost = false;
  bool won = false;
  bool push = false;
  bool nextbutton = false;
  bool roundover = false;


  dealerGoes() {
    setState(() {
      int i = 2;
      while (dealerhandnum() < 16) {
        card c = CardConstuctor.hit(deck);
        dealerHand.add(c);
      }
      if (dealerhandnum() > 21) {
        won = true;
      }
      else if (dealerhandnum() > playerhandnum()) {
        lost = true;
      }
      else if (dealerhandnum() == playerhandnum()) {
        push = true;
      }
      else if (dealerhandnum() < playerhandnum()) {
        won = true;
      }
    });
    }

  void roundDone(){
    setState(() {
      if (won) {
        money += bett * 2;
      }
      if (push) {
        money += bett;
      }
      playhand = 0;
      dealhand = 0;
      lost = false;
      won = false;
      push = false;
      nextbutton = false;
      roundover = false;
      playerHand.clear();
      dealerHand.clear();
      initScreen = false;
      bett = 0;
    });
  }

  void bet(int num) {
    setState(() {
      money = money - num;
      bett = bett + num;
    });
  }

      void play() {
        setState(() {
                initScreen = true;
        hitt();
        hitt();
                card c = CardConstuctor.hit(deck);
                dealerHand.add(facedown);
                dealerHand.add(c);
        });
      }

  void hitt() {
    setState(() {
        card c = CardConstuctor.hit(deck);
        playerHand.add(c);
        if (playerhandnum() > 21) {
          lost = true;
          roundover = true;
        }
    });
  }

  String pic() {
    if (playerHand.length == 0) {
      return "assets/images/blue_back.png";
    }
    else {
      return playerHand[0].assets;
    }
  }

  int dealerhandnum() {
   if (dealerHand.length == 0) {
     return 0;
   }
   int val = 0;
    for (var i in dealerHand) {
      val += i.value;
    }
    dealhand = val;
    return dealhand;
  }

  void stay() {
    setState(() {
      dealerHand[0] = CardConstuctor.hit(deck);
      dealerGoes();
      roundover = true;
    });
  }

  void double() {
    setState(() {
      money -= bett;
      bett = bett * 2;
      hitt();
      if (playerhandnum() > 21) {
        lost = true;
      }
      else {
        dealerGoes();
      }
      roundover = true;
    });
  }

  int playerhandnum() {
    if (playerHand.length == 0) {
      return 0;
    }
    int val = 0;
    for (var i in playerHand) {
       val += i.value;
    }
    playhand = val;
    return playhand;
  }

  @override
  Widget build(BuildContext context) {
      return MaterialApp(
        home: Scaffold(
          body: Stack(
        children: <Widget>[
          Container(
            decoration: new BoxDecoration(
              color: Colors.green,
            ),
          ),
          //1000 dollars button
          Align(
            alignment: Alignment.bottomLeft,
            child: Container(
              height: 50,
              child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                   RaisedButton(
                    onPressed: money != 0 && initScreen == false ? () => bet(1000) : null,
                    color: Colors.redAccent,
                    disabledColor: Colors.white30,
                    child: Center(
                      child: Text(
                        'Bet 1000 Dollars',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  RaisedButton(
                    onPressed: money >= 5000 && initScreen == false ? () => bet(5000) : null,
                    color: Colors.redAccent,
                    disabledColor: Colors.white30,
                    child: Center(
                      child: Text(
                        'Bet 5000 Dollars',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),




          //play button
          Align(
            alignment: Alignment.bottomRight,
            child: Container(
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  RaisedButton(
                    onPressed: bett != 0 && initScreen == false ? () => play() : null,
                    color: Colors.redAccent,
                    disabledColor: Colors.white30,
                    child: Center(
                      child: Text(
                        'PLAY',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              child: Text('Blackjack',
                style: TextStyle(
                  fontSize: 32.0,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0, -.3),
            child: Container(
              child: Text('BLACKJACK PAYS 3 TO 2',
                style: TextStyle(
                  fontSize: 30.0,
                  color: Colors.yellow,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0, -.2),
            child: Container(
              decoration: new BoxDecoration(
                shape: BoxShape.rectangle,
                border: new Border.all(
                  color: Colors.white,
                ),
              ),
              child: Text('DEALER MUST STAND ON 17 AND DRAW TO 16',
                style: TextStyle(
                  fontSize: 15.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0, .2),
            child: Container(
              height: 150.0,
              decoration: new BoxDecoration(
                shape: BoxShape.circle,
                border: new Border.all(
                  color: Colors.white,
                  width: 5.0,
                ),
              ),
            ),
          ),
       Align(
         alignment: Alignment(0, .17),
         child: Container(
           height: 100.0,
           decoration: new BoxDecoration(
             shape: BoxShape.circle,
             color: Colors.red
         ),
       ),
       ),
       Align(
         alignment: Alignment(0, .17),
         child: Container(
           child: Text(bett.toString(),
           style: TextStyle(
             fontSize: 20,
           ),
           ),
       ),
       ),
       Align(
         alignment: Alignment(0.8, .85),
         child: Container(
           height: 50,
          child: Row(
             children: <Widget>[
               RaisedButton(
                 onPressed: initScreen  && roundover == false ? () => hitt() : null,
                 color: Colors.redAccent,
                 disabledColor: Colors.white30,
                 child: Center(
                   child: Text(
                     'Hit',
                     style: TextStyle(
                       color: Colors.white,
                     ),
                   ),
                 ),
               ),
               RaisedButton(
                 onPressed: initScreen && roundover == false ? () => stay() : null,
                 color: Colors.redAccent,
                 disabledColor: Colors.white30,
                 child: Center(
                   child: Text(
                     'Stay',
                     style: TextStyle(
                       color: Colors.white,
                     ),
                   ),
                 ),
               ),
               RaisedButton(
                 onPressed: initScreen  && roundover == false ? () => double() : null,
                 color: Colors.redAccent,
                 disabledColor: Colors.white30,
                 child: Center(
                   child: Text(
                     'Double Down',
                     style: TextStyle(
                       color: Colors.white,
                     ),
                   ),
                 ),
               ),
               RaisedButton(
                 onPressed: initScreen  && roundover ? () => roundDone() : null,
                 color: Colors.redAccent,
                 disabledColor: Colors.white30,
                 child: Center(
                   child: Text(
                     'Continue',
                     style: TextStyle(
                       color: Colors.white,
                     ),
                   ),
                 ),
               ),
             ],
           ),
         ),
       ),

       Align (
         alignment: Alignment(0, .63),
         child: Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: <Widget>[
             for (var i in playerHand)
               Image.asset(i.assets,
               height: 110,),
           ],
           ),
         ),
          Align (
            alignment: Alignment(0, -0.63),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                for (var i in dealerHand)
                  Image.asset(i.assets,
                    height: 110,),
              ],
            ),
          ),
          Align(
            alignment: Alignment(.7, -.7),
            child: Container(
              child: Text(dealerhandnum().toString()),
            ),
          ),

          Align(
            alignment: Alignment(.7, .7),
            child: Container(
              child: Text(playerhandnum().toString()),
            ),
          ),

          Align(
            alignment: Alignment(.9, -.9),
            child: Container(
              decoration: new BoxDecoration(
                shape: BoxShape.rectangle,
                border: new Border.all(
                  color: Colors.white,
                ),
              ),
              child: Text(money.toString() + ' dollars',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment(0, - 0.8),
            child: Container(
              child:
               initScreen  && roundover && lost ? Text("YOU LOSE",
                 style: TextStyle(
                   fontSize: 40,
                   color: Colors.red
                 ),
               ) : null,
            ),
          ),
          Align(
            alignment: Alignment(0, - 0.8),
            child: Container(
              child:
              initScreen  && roundover && won ? Text("YOU WIN",
                style: TextStyle(
                    fontSize: 40,
                    color: Colors.red
                ),
              ) : null,
            ),
          ),
          Align(
            alignment: Alignment(0, - 0.8),
            child: Container(
              child:
              initScreen  && roundover && push ? Text("PUSH",
                style: TextStyle(
                    fontSize: 40,
                    color: Colors.red
                ),
              ) : null,
            ),
          ),
       ],
        ),
        ),
        );


}


  }